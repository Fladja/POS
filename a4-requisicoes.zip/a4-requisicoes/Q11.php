<?php
require('requisicoes.php');

$corpo = ["nome"=>$argv[1],"idade"=>$argv[2], "Content-Type"=>"multipart/form-data"];
$r = enviar_requisicao("$url_api/q11","POST",$corpo);
var_dump($r['codigo'],$r['corpo']);

?>