<?php
require('requisicoes.php');

$nome = $argv[1];
$resp = enviar_requisicao("$url_api/q2/$nome");
var_dump($resp['codigo'], $resp['corpo']);

?>
