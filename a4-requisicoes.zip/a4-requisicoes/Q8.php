<?php
require('requisicoes.php');

$name = [$argv[1] => $argv[2], $argv[3] => $argv[4]];
$uri = http_build_query($name);

$r = enviar_requisicao("$url_api/q4?$uri");
var_dump($r['codigo'],$r['erro']);

?>