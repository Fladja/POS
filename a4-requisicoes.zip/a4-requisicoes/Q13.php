<?php
require('requisicoes.php');

$r = enviar_requisicao("$url_api/q13","PUT");
var_dump($r['codigo'],$r['corpo']);

?>