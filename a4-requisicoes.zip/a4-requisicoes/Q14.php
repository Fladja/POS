<?php
require('requisicoes.php');

$corpo = [$argv[1]=>$argv[2], $argv[3]=>$argv[4]];
$corpo = json_encode($corpo);

$r = enviar_requisicao("$url_api/q14", "PUT", $corpo, array("Content-Type:application/json"));
var_dump($r['codigo'], $r['corpo']);

?>