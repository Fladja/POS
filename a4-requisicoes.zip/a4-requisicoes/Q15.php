<?php
require('requisicoes.php');

$r = enviar_requisicao("$url_api/q15","DELETE");
var_dump($r['codigo'],$r['corpo']);

?>