<?php
require('requisicoes.php');

$r = enviar_requisicao("$url_api/q9/", "POST");
var_dump($r['codigo'],$r['corpo']);

?>