<?php
require('requisicoes.php');

$corpo = ["nome"=>$argv[1],"Content-Type"=>"multipart/form-data"];
$r = enviar_requisicao("$url_api/q10","POST",$corpo);
var_dump($r['codigo'],$r['corpo']);

?>