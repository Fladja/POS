<?php
require('requisicoes.php');

$name = $argv[1];
$r= enviar_requisicao("$url_api/q16/$name","DELETE");
var_dump($r['codigo'],$r['corpo']);

?>