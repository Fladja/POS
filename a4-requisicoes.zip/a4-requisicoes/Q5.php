<?php
require('requisicoes.php');

$r = enviar_requisicao("$url_api/q1");
var_dump($r['codigo'],$r['erro']);

?>