<?php
require('requisicoes.php');

$nome = [$argv[1] => $argv[2], $argv[3] => $argv[4]];
$uri = http_build_query($nome);

$r = enviar_requisicao("$url_api/q18?$uri", "DELETE");
var_dump($r['codigo'], $r['corpo']);

?>