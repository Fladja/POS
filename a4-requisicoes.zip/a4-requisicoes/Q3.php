<?php
require('requisicoes.php');

$name = ['nome' => $argv[1]];
$uri = http_build_query($name);

$r = enviar_requisicao("$url_api/q3?$uri");
var_dump($r['codigo'],$r['corpo']);

?>