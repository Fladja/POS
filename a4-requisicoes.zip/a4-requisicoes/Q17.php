<?php
require('requisicoes.php');

$nome = array("nome"=>$argv[1]);
$uri = http_build_query($nome);

$r = enviar_requisicao("$url_api/q17?$uri","DELETE");
var_dump($r['codigo'],$r['corpo']);

?>