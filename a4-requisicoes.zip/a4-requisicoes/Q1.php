<?php
    require('requisicoes.php');
    //Escreva um programa que envie uma requisição GET ao URL /q1 e exiba o código e corpo da resposta.

    $resp = enviar_requisicao("$url_api/q1");
    var_dump($resp['codigo'],$resp['corpo']);
?>